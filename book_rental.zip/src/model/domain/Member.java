package model.domain;

public class Member {
	private String name;
	private int phonenumber;
	private String bookname;
	
	public Member() {}
	public Member(String name, int phonenumber, String bookname) {
		this.name = name;
		this.phonenumber = phonenumber;
		this.bookname = bookname;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public long getPhonenumber() {
		return phonenumber;
	}
	
	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	public String getMemberBook() {
		return bookname;
	}
	
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	
	public String toString() {
		return name + " " + phonenumber + " " + bookname;
	}
}











