package model.domain;

public class Book {
	private String bookname;
	
	public Book() {}
	public Book(String bookname) {
		this.bookname = bookname;
	}
	
	public String getBookName() {
		return bookname;
	}
	public void setRename(String bookname) {
		this.bookname = bookname;
	}
}














